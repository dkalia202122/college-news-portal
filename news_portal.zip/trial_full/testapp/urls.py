from django.contrib import admin
from django.urls import path,include
from testapp import views

urlpatterns = [
path('', views.home),
path('students/student3', views.stu),
path('faculty/fac', views.fac),
path('events/event', views.eve),

    path('students/deepak', views.stu1),
    path('students/raunak', views.stu2),
    path('students/rudra', views.stu3),
    path('students/rishi', views.stu4),
    path('students/jayant', views.stu5),
    path('students/piyush', views.stu6),
    path('students/aditya', views.stu7),
    path('students/vishesh', views.stu8),

    path('faculty/info/alok1/alok', views.fac1),
    path('faculty/info/anu1/anu', views.fac2),
    path('faculty/info/direc1/direc', views.fac3),
    path('faculty/info/sush1/sush', views.fac4),
    path('faculty/info/sonia1/sonia', views.fac5),

]

from django.shortcuts import render

def home(request):
    return render(request, "testapp/home.html")

def stu(request):
    return render(request, "testapp/students/student3.html")

def fac(request):
    return render(request, "testapp/faculty/fac.html")

def eve(request):
    return render(request, "testapp/events/event.html")


def stu1(request):
    return render(request, "testapp/students/deepak.html")
def stu2(request):
    return render(request, "testapp/students/RAUNAK.html")
def stu3(request):
    return render(request, "testapp/students/rudra.html")
def stu4(request):
    return render(request, "testapp/students/rishi.html")
def stu5(request):
    return render(request, "testapp/students/jayant.html")
def stu6(request):
    return render(request, "testapp/students/piyush.html")
def stu7(request):
    return render(request, "testapp/students/aditya.html")
def stu8(request):
    return render(request, "testapp/students/vishesh.html")


def fac1(request):
    return render(request, "testapp/faculty/info/alok1/alok.html")
def fac2(request):
    return render(request, "testapp/faculty/info/anu1/anu.html")
def fac3(request):
    return render(request, "testapp/faculty/info/direc1/direc.html")
def fac4(request):
    return render(request, "testapp/faculty/info/sush1/sush.html")
def fac5(request):
    return render(request, "testapp/faculty/info/sonia1/sonia.html")
